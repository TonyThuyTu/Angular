import { Component } from '@angular/core';

@Component({
  selector: 'app-lab2',
  standalone: false,
  templateUrl: './lab2.component.html',
  styleUrl: './lab2.component.css'
})
export class Lab2Component {

}
