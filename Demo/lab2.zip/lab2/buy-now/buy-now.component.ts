import { Component } from '@angular/core';

@Component({
  selector: 'app-buy-now',
  standalone: false,
  templateUrl: './buy-now.component.html',
  styleUrl: './buy-now.component.css'
})
export class BuyNowComponent {

}
