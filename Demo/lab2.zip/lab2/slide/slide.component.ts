import { Component } from '@angular/core';

@Component({
  selector: 'app-slide',
  standalone: false,
  templateUrl: './slide.component.html',
  styleUrl: './slide.component.css'
})
export class SlideComponent {

}
